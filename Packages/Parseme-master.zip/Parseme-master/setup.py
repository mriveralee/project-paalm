#!/usr/bin/env python3

from distutils.core import setup

setup(name='parseme',
      version='0.1',
      description='Parseme code expander.',
      author='JacobF',
      author_email='queatz@gmail.com',
      url='http://www.queatz.com/',
      py_modules=['parseme']
)
